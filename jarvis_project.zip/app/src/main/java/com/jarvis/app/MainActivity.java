package com.jarvis.app;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    static final int REQ_SPEECH = 100;
    TextToSpeech tts;
    boolean ttsReady = false;
    TextView status;
    final Map<String, String> apps = new HashMap<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        addApp("com.google.android.youtube", "youtube", "यूट्यूब", "यूटयूब", "यूट्यूबऐप");
        addApp("com.whatsapp", "whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप", "वॉट्सएप");
        addApp("com.android.chrome", "chrome", "क्रोम");
        addApp("com.android.camera", "camera", "कैमरा");
        addApp("com.android.settings", "settings", "सेटिंग", "सेटिंग्स");
        addApp("com.instagram.android", "instagram", "इंस्टाग्राम");
        addApp("com.facebook.katana", "facebook", "फेसबुक");
        addApp("com.google.android.apps.maps", "maps", "मैप", "मैप्स");
        addApp("com.google.android.gm", "gmail", "जीमेल");
        addApp("com.spotify.music", "spotify", "स्पॉटिफाई");
        buildUi();
        tts = new TextToSpeech(this, this);
    }

    void addApp(String pkg, String... names) {
        for (String n : names) apps.put(n, pkg);
    }

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#0A0F1E"));
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(Color.parseColor("#00E5FF"));
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        Button mic = new Button(this);
        mic.setText("🎤");
        mic.setTextSize(64);
        mic.setAllCaps(false);
        mic.setPadding(0, 0, 0, 0);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(Color.parseColor("#00B8D4"));
        mic.setBackground(circle);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(180), dp(180));
        lp.topMargin = dp(56);
        lp.bottomMargin = dp(40);
        mic.setLayoutParams(lp);
        mic.setOnClickListener(v -> listen());
        root.addView(mic);

        status = new TextView(this);
        status.setText("माइक दबाकर बोलिए");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        root.addView(status);

        setContentView(root);
    }

    @Override
    public void onInit(int s) {
        if (s == TextToSpeech.SUCCESS) {
            tts.setLanguage(new Locale("hi", "IN"));
            ttsReady = true;
            say("नमस्ते, मैं जारविस हूँ। माइक दबाइए।");
        }
    }

    void say(String t) {
        status.setText(t);
        if (ttsReady) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    void listen() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए...");
        try {
            startActivityForResult(i, REQ_SPEECH);
        } catch (Exception e) {
            say("आपके फ़ोन में Google वॉइस सर्च नहीं मिला");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SPEECH && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                String t = r.get(0).toLowerCase();
                status.setText("आपने कहा: " + t);
                handle(t);
            }
        }
    }

    static boolean has(String t, String... ws) {
        for (String w : ws) if (t.contains(w)) return true;
        return false;
    }

    void handle(String t) {
        String ns = t.replace(" ", "");

        if (has(t, "अलार्म", "alarm", "अलार्म")) {
            if (!setAlarm(t)) say("समय समझ नहीं आया। बोलिए: सुबह 6:30 का अलार्म लगाओ");
            return;
        }
        if ((has(ns, "स्क्रीन", "screen") && has(t, "बंद", "off", "ऑफ")) || has(ns, "फोनलॉक", "लॉककरो", "lockphone")) {
            screenOff();
            return;
        }
        if (has(ns, "टॉर्च", "टार्च", "torch", "flashlight", "फ्लैशलाइट", "लाइट")) {
            boolean off = has(t, "बंद", "off", "ऑफ", "बुझा");
            torch(!off);
            return;
        }
        for (Map.Entry<String, String> e : apps.entrySet()) {
            if (ns.contains(e.getKey())) {
                say(e.getKey() + " खोल रहा हूँ");
                if (!openApp(e.getValue())) {
                    if (e.getValue().equals("com.google.android.youtube")) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")));
                    } else {
                        say("यह ऐप फ़ोन में नहीं मिला");
                    }
                }
                return;
            }
        }
        if (has(ns, "समय", "टाइम", "time")) {
            say("अभी " + new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(new Date()) + " हुए हैं");
            return;
        }
        if (has(ns, "बैटरी", "battery")) {
            Intent bi = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bi != null) {
                int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                int sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
                say("बैटरी " + (lvl * 100 / sc) + " प्रतिशत है");
            }
            return;
        }
        say("यह कमांड मुझे अभी नहीं आती");
    }

    boolean openApp(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        startActivity(i);
        return true;
    }

    void torch(boolean on) {
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                Boolean f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (f != null && f) {
                    cm.setTorchMode(id, on);
                    say(on ? "टॉर्च चालू" : "टॉर्च बंद");
                    return;
                }
            }
            say("फ़ोन में फ्लैश नहीं मिला");
        } catch (Exception e) {
            say("टॉर्च नहीं चल पाई");
        }
    }

    void screenOff() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName cn = new ComponentName(this, AdminReceiver.class);
        if (dpm.isAdminActive(cn)) {
            dpm.lockNow();
        } else {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, cn);
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "स्क्रीन बंद करने के लिए यह अनुमति ज़रूरी है");
            startActivity(i);
            say("पहले अनुमति दीजिए, फिर दोबारा बोलिए");
        }
    }

    boolean setAlarm(String t) {
        Matcher m = Pattern.compile("(\\d{1,2})(?:\\s*[:.]\\s*(\\d{2}))?").matcher(t);
        if (!m.find()) return false;
        int h = Integer.parseInt(m.group(1));
        int mi = m.group(2) != null ? Integer.parseInt(m.group(2)) : 0;
        boolean pm = has(t, "शाम", "रात", "दोपहर", "pm", "p.m");
        boolean am = has(t, "सुबह", " am", "a.m");
        if (pm && h < 12) h += 12;
        if (am && h == 12) h = 0;
        if (h > 23 || mi > 59) return false;
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        i.putExtra(AlarmClock.EXTRA_HOUR, h);
        i.putExtra(AlarmClock.EXTRA_MINUTES, mi);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        try {
            startActivity(i);
            say(String.format(Locale.US, "अलार्म %02d:%02d बजे के लिए सेट हो गया", h, mi));
        } catch (Exception e) {
            say("अलार्म सेट नहीं हो पाया");
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
